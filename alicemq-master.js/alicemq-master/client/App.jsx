import React from 'react';
import Main from './Containers/Main.jsx';

const App = (props) => {
    return (
        <div>
            <Main />
        </div>
    )
};

export default App;